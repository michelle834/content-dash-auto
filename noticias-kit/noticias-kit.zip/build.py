"""heru · Resumen semanal de noticias fiscales (cada viernes). Kit autocontenido.
Uso: python3 build.py semana.json  ->  out/<fecha>/01..NN.png + out/<fecha>-vista.png
semana.json = {"fecha":"2026-11-13","rango":"del 7 al 13 de noviembre de 2026",
  "slides":[["emoji","pastilla","titulo con <span class=hl>1-3 palabras</span>","texto con <b>negritas</b>","fuente"], ..., ["cta","texto del cierre","fuente"]]}
Portada: portada-sin-fecha.png (la de Mich sin fecha) + la fecha en Lexend Deca 600, 37 px, en (98,944)."""
import sys, json, base64, pathlib
from PIL import Image
from playwright.sync_api import sync_playwright
K = pathlib.Path(__file__).resolve().parent
F = K / 'fonts'
def b64(p, mime): return f"data:{mime};base64," + base64.b64encode(pathlib.Path(p).read_bytes()).decode()
LOGO = b64(K / 'heru-logo-azul.png', 'image/png')
TG = F; LEX = F
CSS = f"""
@font-face{{font-family:'Heros';src:url({b64(F/'texgyreheros-bold.otf','font/otf')});font-weight:700}}
@font-face{{font-family:'LD';src:url({b64(LEX/'lexend-deca-latin-400-normal.woff2','font/woff2')});font-weight:400}}
@font-face{{font-family:'LD';src:url({b64(LEX/'lexend-deca-latin-700-normal.woff2','font/woff2')});font-weight:700}}
*{{margin:0;padding:0;box-sizing:border-box}}
.s{{position:relative;width:1080px;height:1440px;overflow:hidden;background:#F5EFE3;
   background-image:linear-gradient(#ECE5D8 2px,transparent 2px),linear-gradient(90deg,#ECE5D8 2px,transparent 2px);
   background-size:36px 36px;font-family:'LD';color:#000}}
.logo{{position:absolute;top:66px;right:90px;width:118px}}
.arrow{{position:absolute;top:52px;left:503px;width:74px;height:74px;border-radius:50%;border:2px solid #C9BFAE;
       display:flex;align-items:center;justify-content:center;font-family:'LD';font-size:30px;color:#6B6356}}
.emo{{font-family:'Noto Color Emoji';font-size:132px;line-height:1}}
.col{{position:absolute;left:90px;right:90px;top:300px;display:flex;flex-direction:column;align-items:flex-start}}
.pill{{background:#1790EC;color:#FFF;font-family:'Heros';font-weight:700;font-size:40px;border-radius:60px;
      padding:24px 42px;margin-top:56px;letter-spacing:-.01em}}
.card{{background:#FFF;border-radius:48px;padding:58px 58px 64px;margin-top:18px;align-self:stretch}}
.card h1{{font-family:'Heros';font-weight:700;font-size:74px;line-height:1.22;letter-spacing:-.02em}}
.hl{{background:#15D1FE;padding:0 16px;-webkit-box-decoration-break:clone;box-decoration-break:clone}}
.card p{{font-size:37px;line-height:1.55;color:#3A3A3A;margin-top:34px}}
.card p b{{font-family:'LD';font-weight:700;color:#000}}
.src{{position:absolute;left:96px;bottom:84px;right:200px;font-size:30px;color:#8A8274}}
.pg{{position:absolute;right:96px;bottom:84px;font-size:28px;color:#8A8274}}
.lbl{{font-family:'LD';font-weight:700;font-size:30px;letter-spacing:.16em;text-transform:uppercase;color:#1790EC;margin-top:54px}}
.cov{{font-family:'Heros';font-weight:700;font-size:112px;line-height:1.22;letter-spacing:-.02em;
     text-transform:uppercase;margin-top:26px}}
.cov .hl{{white-space:nowrap}}
.covsub{{font-size:42px;line-height:1.45;color:#2B2B2B;margin-top:40px}}
.cue{{position:absolute;left:0;right:0;bottom:84px;text-align:center;font-size:30px;color:#6B6356}}
"""


def body(emo, pill, h1, p, src, n, tot):
    return f'''<div class="s"><div class="arrow">→</div><img class="logo" src="{LOGO}">
<div class="col"><div class="emo">{emo}</div><div class="pill">{pill}</div>
<div class="card"><h1>{h1}</h1><p>{p}</p></div></div>
<div class="src">{src}</div><div class="pg">{n}/{tot}</div></div>'''


def cta(p, src, n):
    return f'''<div class="s"><img class="logo" src="{LOGO}">
<div class="col" style="top:400px"><div class="emo">🔖</div>
<div class="card" style="margin-top:60px"><h1><span class="hl">Guárdalo</span></h1><p>{p}</p></div></div>
<div class="src">{src}</div><div class="pg">{n}/{n}</div></div>'''


def hl(t):
    return f'<span class="hl">{t}</span>'



def hl(t): return f'<span class="hl">{t}</span>'

def portada(rango, out):
    fonts = ''.join(f"@font-face{{font-family:LD6;src:url({b64(F/f'lexend-deca-{s}-600-normal.woff2','font/woff2')});font-weight:600}}" for s in ('latin','latin-ext'))
    html = f"""<html><head><meta charset="utf-8"><style>{fonts}*{{margin:0}}body{{width:1086px;height:1448px;background:url({b64(K/'portada-sin-fecha.png','image/png')})}}
    .d{{position:absolute;left:98px;top:944px;font-family:LD6;font-weight:600;font-size:37px;color:#000;white-space:nowrap}}</style></head><body><div class="d">{rango}</div></body></html>"""
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_page(viewport={'width':1086,'height':1448}, device_scale_factor=1)
        pg.set_content(html); pg.wait_for_timeout(400); pg.screenshot(path=str(out.with_suffix('.tmp.png'))); b.close()
    Image.open(out.with_suffix('.tmp.png')).convert('RGB').resize((1080,1440), Image.LANCZOS).save(out)
    out.with_suffix('.tmp.png').unlink()

def build(sem):
    out = K / 'out' / sem['fecha']; out.mkdir(parents=True, exist_ok=True)
    portada(sem['rango'], out / '01.png')
    tot = len(sem['slides']) + 1; files = [out / '01.png']
    with sync_playwright() as p:
        b = p.chromium.launch(); pg = b.new_page(viewport={'width':1080,'height':1440}, device_scale_factor=1)
        for i, s in enumerate(sem['slides'], 2):
            html = cta(s[1], s[2], tot) if s[0] == 'cta' else body(*s, i, tot)
            pg.set_content(f'<!doctype html><html><head><meta charset="utf-8"><style>{CSS}</style></head><body>{html}</body></html>')
            pg.wait_for_timeout(300); f = out / f'{i:02d}.png'
            pg.screenshot(path=str(f), clip={'x':0,'y':0,'width':1080,'height':1440}); files.append(f)
        b.close()
    ims = [Image.open(x).convert('RGB') for x in files]; w, h = 300, 400; rows = (len(ims)+3)//4
    sheet = Image.new('RGB', (w*4+50, h*rows+10*(rows+1)), '#FFFFFF')
    for k, im in enumerate(ims): sheet.paste(im.resize((w,h)), (10+(k%4)*(w+10), 10+(k//4)*(h+10)))
    sheet.save(K / 'out' / f"{sem['fecha']}-vista.png"); print('ok', sem['fecha'], len(files))

if __name__ == '__main__':
    build(json.load(open(sys.argv[1], encoding='utf-8')))
